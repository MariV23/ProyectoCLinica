/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyecto_clinica;

import formularios.FrmLogin;

/**
 *
 * @author vmary
 */
public class Principal {
    
    public static void main(String[] args) {
        FrmLogin frmLogin = new FrmLogin();
        frmLogin.setSize(450,450);
        frmLogin.setTitle("Iniciar Sesion");
        frmLogin.setLocation(750, 250);
        frmLogin.setVisible(true);
    }
}
